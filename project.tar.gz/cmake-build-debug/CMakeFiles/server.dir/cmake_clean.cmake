file(REMOVE_RECURSE
  "CMakeFiles/server.dir/link.d"
  "CMakeFiles/server.dir/server/server.c.o"
  "CMakeFiles/server.dir/server/server.c.o.d"
  "server"
  "server.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/server.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
